$( document ).ready(function() {
	$(document).foundation();
	
				// Типы элементов в справочнике HTML
			$('#tag-filter input[type=checkbox]').on('click', function () {
				if ($(this).val() == 'tag-all') {
					if ($(this).prop('checked') == false) { $('#tag-filter input[type=checkbox]').prop('checked', false); }
					else { $('#tag-filter input[type=checkbox]').prop('checked', true); }
				}
				if ($(this).prop('checked') == true) {
					var tag = $(this).parent().attr('class');
					$("li.f").filter("." + tag).removeClass('transparency');
				}	else {
					var tag = $(this).parent().attr('class');
					$("li.f").filter("." + tag).addClass('transparency');
				}
				
				// Обходим всё и сохраняем в кукисах
				var data = new Object(); // Создаём объект

				$('#tag-filter label').each(function(){
					var filter = $(this).attr("class"); // Получаем имя фильтра
					var check = $(this).children('input').prop('checked'); // Поставлена галочка или нет
					data[filter] = check; // Формируем нужный объект
				});
				
			});
			
})
 
